# src/anomalies.py
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, count, month, year, avg, stddev_samp, desc

def monthly_counts(df_ok: DataFrame) -> DataFrame:
    return (
        df_ok.withColumn("y", year(col("event_date")))
            .withColumn("m", month(col("event_date")))
            .groupBy("y", "m")
            .agg(count("*").alias("total"))
            .orderBy("y", "m")
    )

def detect_spikes_mean_std(df_month: DataFrame, k: float = 2.0) -> DataFrame:
    stats = df_month.agg(
        avg(col("total")).alias("mu"),
        stddev_samp(col("total")).alias("sigma")
    ).collect()[0]

    mu = stats["mu"]
    sigma = stats["sigma"]

    # Si sigma es None (pocos datos), devuelve vacío ordenado
    if sigma is None:
        return df_month.limit(0)

    threshold = mu + k * sigma

    return (
        df_month.filter(col("total") >= threshold)
                .orderBy(desc("total"))
    )
