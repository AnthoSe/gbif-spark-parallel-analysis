# src/spark_session.py
from pyspark.sql import SparkSession
from .config import Config

def build_spark(cfg: Config) -> SparkSession:
    spark = (
        SparkSession.builder
        .appName(cfg.app_name)
        .master(cfg.master)
        .config("spark.sql.shuffle.partitions", str(cfg.shuffle_partitions))
        .getOrCreate()
    )
    return spark
