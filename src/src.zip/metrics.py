# src/metrics.py
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, count, desc

def total_by_region(df_ok: DataFrame, region_col: str) -> DataFrame:
    return (
        df_ok.groupBy(col(region_col).alias("region"))
        .agg(count("*").alias("total_registros"))
        .orderBy(desc("total_registros"))
    )

def top10_entities(df_ok: DataFrame, entity_col: str) -> DataFrame:
    return (
        df_ok.groupBy(col(entity_col).alias("entidad"))
        .agg(count("*").alias("total"))
        .orderBy(desc("total"))
        .limit(10)
    )

def failed_pct_by_region(df_bad: DataFrame, df_all: DataFrame, region_col: str) -> DataFrame:
    # Total por región (all)
    total = (
        df_all.groupBy(col(region_col).alias("region"))
        .agg(count("*").alias("total"))
    )
    # Invalidos por región
    bad = (
        df_bad.groupBy(col(region_col).alias("region"))
        .agg(count("*").alias("invalidas"))
    )
    # Join + porcentaje
    joined = total.join(bad, on="region", how="left").fillna(0, subset=["invalidas"])
    return joined.select(
        col("region"),
        col("total"),
        col("invalidas"),
        (col("invalidas") / col("total") * 100.0).alias("pct_invalidas")
    ).orderBy(desc("pct_invalidas"))
