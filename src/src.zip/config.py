# src/config.py
from dataclasses import dataclass

@dataclass
class Config:
    app_name: str = "Avance2-GBIF-Spark"
    master: str = "local[*]"          # Avance 2: local/pseudo-distribuido
    shuffle_partitions: int = 200     # ajustable (documentar en PDF)
    input_path: str = "data/gbif_ecuador.tsv"
    input_format: str = "tsv"         # TSV => sep '\t'
    output_base: str = "output"
    output_format: str = "csv"        # csv o parquet (Avance 2)
    write_mode: str = "overwrite"
