# src/main.py
from .config import Config
from .spark_session import build_spark
from .io_utils import read_gbif, write_df
from .cleaning import clean_and_validate
from .metrics import total_by_region, top10_entities, failed_pct_by_region
from .anomalies import monthly_counts, detect_spikes_mean_std

def main():
    cfg = Config()
    spark = build_spark(cfg)

    # 1) Carga distribuida
    df_raw = read_gbif(spark, cfg)

    # 2) Limpieza/validación
    df_ok, df_bad, meta = clean_and_validate(df_raw)

    region_col = meta["region_col"]
    entity_col = meta["entity_col"]

    # 3) Métricas principales
    df_total_region = total_by_region(df_ok, region_col)
    df_top10 = top10_entities(df_ok, entity_col)
    df_failed_pct = failed_pct_by_region(df_bad, df_raw, region_col)

    # 4) Anomalías básicas (meses con picos)
    df_month = monthly_counts(df_ok)
    df_spikes = detect_spikes_mean_std(df_month, k=2.0)

    # Acciones (para evidenciar jobs/stages)
    print("RAW:", df_raw.count())
    print("OK :", df_ok.count())
    print("BAD:", df_bad.count())

    df_total_region.show(20, truncate=False)
    df_top10.show(10, truncate=False)
    df_failed_pct.show(20, truncate=False)
    df_spikes.show(50, truncate=False)

    # 5) Persistencia
    write_df(df_total_region, cfg, "01_total_por_region")
    write_df(df_top10, cfg, "02_top10_entidades")
    write_df(df_failed_pct, cfg, "03_pct_invalidas_por_region")
    write_df(df_month, cfg, "04_conteo_mensual")
    write_df(df_spikes, cfg, "05_spikes_mensuales")

    spark.stop()

if __name__ == "__main__":
    main()
