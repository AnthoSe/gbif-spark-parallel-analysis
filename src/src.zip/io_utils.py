# src/io_utils.py
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from .config import Config
import os

def read_gbif(spark: SparkSession, cfg: Config) -> DataFrame:
    if cfg.input_format.lower() == "tsv":
        df = (
            spark.read
            .option("header", "true")
            .option("sep", "\t")
            .option("inferSchema", "true")
            .csv(cfg.input_path)
        )
    else:
        raise ValueError("Formato no soportado. Usa TSV en Avance 2.")

    return df

def write_df(df: DataFrame, cfg: Config, name: str) -> str:
    out_path = os.path.join(cfg.output_base, name)

    if cfg.output_format.lower() == "csv":
        (
            df.coalesce(1)  # para entrega/inspección (no es optimización avanzada)
            .write.mode(cfg.write_mode)
            .option("header", "true")
            .csv(out_path)
        )
    elif cfg.output_format.lower() == "parquet":
        df.write.mode(cfg.write_mode).parquet(out_path)
    else:
        raise ValueError("Formato de salida no soportado (csv/parquet).")

    return out_path
