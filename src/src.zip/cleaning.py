# src/cleaning.py
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, to_date

def pick_existing_col(df: DataFrame, candidates: list[str]) -> str:
    cols = set(df.columns)
    for c in candidates:
        if c in cols:
            return c
    raise ValueError(f"No encontré ninguna columna entre: {candidates}")

def clean_and_validate(df: DataFrame) -> tuple[DataFrame, DataFrame, dict]:
    """
    Retorna:
    - df_ok: registros válidos
    - df_bad: registros inválidos (útil para % fallidas)
    - meta: diccionario con columnas usadas
    """
    # Columnas típicas GBIF (pueden variar según export)
    col_region = pick_existing_col(df, ["stateProvince", "province", "provincia"])
    col_entity = pick_existing_col(df, ["species", "scientificName", "taxon"])
    col_date   = pick_existing_col(df, ["eventDate", "date", "fecha"])

    # Normaliza fecha si viene como string compatible
    df2 = df.withColumn("event_date", to_date(col(col_date)))

    # Criterio de válido: región y entidad no nulas, y fecha parseable
    df_ok = df2.filter(
        col(col_region).isNotNull() &
        col(col_entity).isNotNull() &
        col("event_date").isNotNull()
    )

    df_bad = df2.subtract(df_ok)

    meta = {
        "region_col": col_region,
        "entity_col": col_entity,
        "date_col": col_date
    }
    return df_ok, df_bad, meta
